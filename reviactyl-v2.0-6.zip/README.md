# Thank You For Choosing RevixLabs!
Installing Reviactyl is simple. Just follow our https://docs.revix.cc/getting-started/installation guide.

**DISCORD**: https://discord.gg/ZrRsNKK94R
